package xmlDemo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;


public class ReadXML {
	
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
		
		
		 int choice=0;  
		 BufferedReader rd = new BufferedReader(new InputStreamReader(System.in));
		 
		  
		    System.out.println("Menu for XML Parsing\n");  
		  
		    while(choice != 6)  
		    {  
		        System.out.println("\nSelect from the following options\n");  
		        System.out.println("\n1.Total Number Of Subjects\n2.Subject Names"
		        		+ "\n3.Enter the marks above which to show details"
		        		+ "\n4.Total Students in all schools"
		        		+ "\n5.Total number of students in a school"
		        		+ "\n6.Exit");  
		        System.out.println("\n Enter your choice \n");        
		        choice = Integer.parseInt(rd.readLine());
		     		    
		    switch(choice)  
		    {  
		        case 1:  
		        {  
		                  
		            ReadUtil.totalSubjects();		            
		            break;  
		        }  
		        case 2:  
		        {  
		            ReadUtil.getSubjectNames();
		            break;  
		        }  
		        case 3:  
		        {  
		        	System.out.println("Enter the marks for which details to be retrieved :");
		        	int mark = Integer.parseInt(rd.readLine());
		        	ReadUtil.getStudentsGradeA(mark);
		            break;  
		        }  
		        case 4:  
		        {  
		        	ReadUtil.totalStudentsInAllSchools();
		            break;  
		        }
		        case 5:  
		        {  
		        	System.out.println("Enter the school name to find the student strength :");		        	
		        	String school = rd.readLine();
		        	ReadUtil.totalStudentsInSchool(school);
		            break;  
		        }
		        case 6:   
		        {  
		            System.out.println("Exiting....");  
		            System.exit(0);  
		            break;   
		        }  
		        default:  
		        {  
		            System.out.println("Please Enter valid choice ");  
		        }   
		    };  
		}
		
	
	}
}