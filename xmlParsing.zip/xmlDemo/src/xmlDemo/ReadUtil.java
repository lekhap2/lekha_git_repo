package xmlDemo;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ReadUtil {
	
	public static NodeList students;
	
	public static void totalSubjects() {
		 Set<String> subjectSet = new HashSet<String>();
		 read();
		 for (int itr = 0; itr < students.getLength(); itr++)   
			{  
			Node node = students.item(itr);  
					if (node.getNodeType() == Node.ELEMENT_NODE)   
					{  
							Element eElement = (Element) node;  
							subjectSet.add(eElement.getElementsByTagName("subject").item(0).getTextContent());
					}
			}
		 System.out.println("Total Number of Subjects are :"+subjectSet.size());
		
	}
	
	public static void getSubjectNames() {
		 Set<String> subjectSet = new HashSet<String>();
		 read();
		 for (int itr = 0; itr < students.getLength(); itr++)   
			{  
			Node node = students.item(itr);  
					if (node.getNodeType() == Node.ELEMENT_NODE)   
					{  
							Element eElement = (Element) node;  
							subjectSet.add(eElement.getElementsByTagName("subject").item(0).getTextContent());
					}
			}
		 for (String string : subjectSet) {
			System.out.println(string);
		 }
		
	}
	
	public static void getStudentsGradeA(int mark) {
		 read();
		 List<Student> studentList = new ArrayList<Student>();
		for (int itr = 0; itr < students.getLength(); itr++)   
			{  
			Node node = students.item(itr);  
				if (node.getNodeType() == Node.ELEMENT_NODE)   
					{  
							Element eElement = (Element) node;  
							int mks = Integer.parseInt(eElement.getElementsByTagName("marks").item(0).getTextContent());
							if(mks > mark) {
								Student std = new Student();
								std.setFirstName(eElement.getElementsByTagName("firstname").item(0).getTextContent());
								std.setLastName(eElement.getElementsByTagName("lastname").item(0).getTextContent());
								std.setId(Integer.parseInt(eElement.getElementsByTagName("id").item(0).getTextContent()));
								std.setSubject(eElement.getElementsByTagName("subject").item(0).getTextContent());
								std.setMarks(mks);
								std.setSchool(eElement.getElementsByTagName("school").item(0).getTextContent());
								studentList.add(std);
							}

					}
		
			}
			System.out.println("Details of the students :");
			for (Student student : studentList) {
				System.out.println(student.getId());
				System.out.println(student.getFirstName());
				System.out.println(student.getLastName());
				System.out.println(student.getSchool());
				System.out.println(student.getSubject());
				System.out.println(student.getMarks());
				System.out.println("-------------------------------");
			}
		
	}
	
	
	public static int totalStudentsInAllSchools() {
		read();
		System.out.println("Total number of students in all schools :"+students.getLength());
		return 0;
	}
	
	public static void totalStudentsInSchool(String school) {
		read();
		System.out.println("Total number of students in all schools :"+students.getLength());
		int numberOfStudents = 0;
		for (int itr = 0; itr < students.getLength(); itr++)   
		{  
		Node node = students.item(itr);  
			System.out.println("\nNode Name :" + node.getNodeName());  
				if (node.getNodeType() == Node.ELEMENT_NODE)   
				{  
						Element eElement = (Element) node;  
						String schoolName = eElement.getElementsByTagName("school").item(0).getTextContent();
						if(school.equalsIgnoreCase(schoolName)) {
							numberOfStudents++;
						}
				}
		}
		System.out.println("Number of students in school :"+school+" is "+numberOfStudents);
		
	}
	
	
	public static void read() {
		File file = new File("D:\\User\\lprabhakaran\\eclipse-workspace\\xmlDemo\\src\\xmlDemo\\demo.xml");  
		try {
		DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();  
		Document document = documentBuilder.parse(file);  
		document.normalize();
		students = document.getDocumentElement().getElementsByTagName("student");
		}catch(Exception e) {
			System.out.println(e);
		}
		
	}

}
